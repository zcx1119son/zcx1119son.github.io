package ch08.sec07;
	
public class serviceImp1 implements Service{
	
}

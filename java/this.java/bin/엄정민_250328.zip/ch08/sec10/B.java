package ch08.sec10;

public class B implements A{

}

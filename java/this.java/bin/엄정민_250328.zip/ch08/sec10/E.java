package ch08.sec10;

public class E extends C{

}

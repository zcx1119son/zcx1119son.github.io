package ch08.sec10;

public class D extends B{

}

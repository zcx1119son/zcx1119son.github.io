package ch08.sec10;

public interface A {

}

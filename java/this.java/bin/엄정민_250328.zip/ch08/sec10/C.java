package ch08.sec10;

public class C implements A{

}

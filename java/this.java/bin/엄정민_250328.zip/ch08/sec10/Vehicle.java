package ch08.sec10;

public interface Vehicle {
	void run();
}

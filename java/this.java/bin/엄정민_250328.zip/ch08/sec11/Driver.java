package ch08.sec11;

public class Driver {
	void drive(Vehicle vehicle) {
		vehicle.run();
	}
}

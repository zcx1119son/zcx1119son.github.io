package ch08.sec11;

public interface Tire {
	void roll();
}

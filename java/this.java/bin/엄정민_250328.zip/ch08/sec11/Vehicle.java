package ch08.sec11;

public interface Vehicle {
	void run();
}

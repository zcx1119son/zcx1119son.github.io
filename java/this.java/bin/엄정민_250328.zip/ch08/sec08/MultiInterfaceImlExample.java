package ch08.sec08;

public class MultiInterfaceImlExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RemoteControl rc=new SmartTelevision();
		rc.turnOn();
		rc.turnOff();
		Searchable searchable=new SmartTelevision();
		searchable.search("https://www.youtube.com");
	}

}

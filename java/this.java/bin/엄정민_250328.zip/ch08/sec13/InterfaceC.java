package ch08.sec13;

public interface InterfaceC extends InterfaceB{
	void methodC();
}
